const Todo=require("../models/Todo");

exports.getTodo=async(req,res)=>{
    try{
        // fetch all todo item from databse
        // find funtion use kr ke sare ke sare todo item fetch kr skte hai
        const todos=await Todo.find({});

        ///response  ko update kr de
        res.status(200)
        .json({
            success:true,
            data:todos,
            message:"Enter Todo Data is Fetched"
        })

    }
    catch(err){
        console.log(err);
        res.status(500)
        .json({
                success: false,
                err:err.message,
                message:'Server Error',

        })
    }
}
exports.updateTodo=async(req,res)=>{
    // extract todo item basic of id
    try{
          const {id}=req.params;
          const{title,description}=req.body;
          const todo=await Todo.findByIdAndUpdate(
            {_id:id},
            {title,description,updateAt:Date.now()}
            
          )
          res.status(200).json({
            success:true,
            data:todo,
            message:'updated Successfully',
          })
    }
    catch(err){
        console.log(err);
        res.status(500)
        .json({
                success: false,
                err:err.message,
                message:'Server Error',

        })

    }

}
