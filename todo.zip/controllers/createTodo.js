// imports
const Todo=require("../models/Todo");

// define route handler
// we can do exports in this way also
exports.createTodo=async(req,res)=>{
    try {
        //extract title and body from req body
        const {title,description}=req.body;
        // create a new Todo Obj and insert in DB
        // create vle method se title ,descirption  creaete krte thae
        // todo object create kiya and insert kr diya hu db ke andar
        const response=await Todo.create({title,description});
        res.status(200).json({
            success:true,
            data:response,
            message:'Entry Created Successfull'
        })


    } catch (err) {
        console.error(err);
        console.log(err)
        res.status(500)
        .json({
            success:false,
            data:"Internal Server Error",
            message:err.message,
        })
        
    }
}
