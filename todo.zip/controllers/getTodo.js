const Todo=require("../models/Todo");

exports.getTodo=async(req,res)=>{
    try{
        // fetch all todo item from databse
        // find funtion use kr ke sare ke sare todo item fetch kr skte hai
        const todos=await Todo.find({});

        ///response  ko update kr de
        res.status(200)
        .json({
            success:true,
            data:todos,
            message:"Enter Todo Data is Fetched"
        })

    }
    catch(err){
        console.log(err);
        res.status(500)
        .json({
                success: false,
                err:err.message,
                message:'Server Error',

        })
    }
}

// single Todo  hmko chayiye parameter ke andar id  pass kr di  hai
exports.getTodoById=async(req,res)=>{
    // extract todo item basic of id
    try{
            //we can find the id in two ways
            // const {id}=req.params;
            const id = req.params.id; 
            const todo=await Todo.findById({_id:id});
            //findbyId is jaha pe voe vle id mil jaye voe return kr jaye 
            //given for given id not found
            if(!todo){
                return res.status(404).json({
                    success:false,
                    message:"No Data Found with Given Id",
                })
            }
            //agar id mila data found
            res.status(200).json({
                success:true,
                data:todo,
                message:`Todo ${id} data successfully fetched`,
            })

    }
    catch(err){
        console.log(err);
        res.status(500)
        .json({
                success: false,
                err:err.message,
                message:'Server Error',

        })

    }

}
