// const express=require('express');
// const app=express();
// app.listen(3000,()=>{
//     console.log("Server started 3000");
// })
// app.get('/',(req,res)=>{
//     res.send("Hello Jee Kaise oh sb");
// })

// const bodyParser=require('body-parser');
// app.use(bodyParser.json());

// const mangoose=require('mongoose');
// mangoose.connect('mongodb://localhost:27017/myDatabase',{
//     useNewUrlParser:true,
//     useUnifiedTopology:true,
// })
// .then(()=>console.log("Conneciton  success"))
// .catch((error)=>{console.log("recived an error")})



// driver Code
const express=require('express');
const app=express();


// load config  of Envorment file
//  require("dotenv")  this means import dotenv file
//.config means process
// Loads .env file contents into process.env by default. If DOTENV_KEY is present, it smartly attempts to load encrypted .env.vault file contents into process.env.
require("dotenv").config();
//succesfullyport numnikal liya nhi to 4000 chle ga
const PORT=process.env.PORT || 4000;
// app.listen(3000,()=>{
//     console.log("App is running successfully");
// })
// middleware is to parase json  req bodys
// middle were we user  kr paye ge app.use kr ke
app.use(express.json());

// import routed for TODO API
const todoRoutes=require("./routes/todos");
// mount(ADD oh jata ) the todo Aspi ROutes
//jb bhi hmre pass request aye gi api/v1 ke sath hm usse todoRoutes  ke route vli file  me trnasfer kr duga
// /api/v1   basically ya hm versionning kr reh hai    without  this sirf '/' likhe ke bhi kr skte  thae
app.use("/api/v1",todoRoutes);


// server strt
app.listen(PORT,()=>{
    console.log(`Server Started succesfully at ${PORT}`);

})

// Db conneciton
const dbConnect=require("./config/database");
dbConnect();


// default routes
app.get("/",(req,res)=>{
   res.send(`<h1> THis is home Page </h1>`); 
})